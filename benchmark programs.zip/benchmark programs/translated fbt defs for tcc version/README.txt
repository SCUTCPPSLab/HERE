Default location of this directory in the test: /home/pi/fbtlib

This location is used in Line 58 of /FORTE_TCC/src/modules/class2_device/XMLParser4FB.cpp for loading XML files.