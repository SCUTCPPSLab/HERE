/*******************************************************************************
  * Copyright (c) 2011 ACIN
  * All rights reserved. This program and the accompanying materials
  * are made available under the terms of the Eclipse Public License v1.0
  * which accompanies this distribution, and is available at
  * http://www.eclipse.org/legal/epl-v10.html
  *
  * Contributors:
  *     Monika Wenger
  *      - initial implementation and rework communication infrastructure
  *******************************************************************************/
#include "forte_any_num.h"

DEFINE_FIRMWARE_DATATYPE(ANY_NUM, g_nStringIdANY_NUM)
