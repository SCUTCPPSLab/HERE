Mini-XML : https://www.msweet.org/mxml/, the latest 3.2 version 

Tiny CC: https://repo.or.cz/w/tinycc.git, the latest 0.9.27 version